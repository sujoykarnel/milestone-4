// basic mathematics between 2 numbers

const num1 = 10;
const num2 = 7;

// sum
const sum = num1 + num2;
console.log('Sum :', sum);

// substract
const sub = num1 - num2
console.log('Sub :', sub);

// multiply
const multiply = num1 * num2;
console.log('Multiply :', multiply);

// divide
const div=num1/num2;
console.log('Divide :', div.toFixed(2));

// modulus
const mod = num1%num2;
console.log('Remainder :', mod);