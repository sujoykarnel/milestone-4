//declare by let & const and change which is can be changed.

const myName = 'Sujoy Das';
let myAge = 28;

// 2 years later my age is

myAge = myAge + 2;
console.log('My Name:', myName);
console.log('2 years later my age:', myAge);