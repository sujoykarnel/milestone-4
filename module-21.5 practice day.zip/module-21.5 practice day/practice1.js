// declare 3 variable string, number, boolean 

var myName = 'Sujoy Das';
var myAge = 28;
var isStudent = false;

console.log(typeof (myName));
console.log(typeof (myAge));
console.log(typeof (isStudent));